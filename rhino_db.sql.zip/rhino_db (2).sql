-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 15, 2017 at 07:44 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rhino_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_ip_blocked` (IN `host` TEXT)  NO SQL
BEGIN

	SELECT *
    FROM `ip_blocked`
    WHERE `hostname` = host;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `get_users_id` (IN `userid` INT(11))  NO SQL
BEGIN

	SELECT U.*, UI.fname, UI.lname, UL.pos_alias, UL.pos_name
    FROM users U 
    INNER JOIN users_info UI 
    ON (U.user_id = UI.user_id)
    INNER JOIN users_level UL
    ON (U.pos_id = UL.id)
    WHERE U.user_id = userid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `get_users_username` (IN `user` VARCHAR(64))  NO SQL
BEGIN

	SELECT U.*, UI.fname, UI.lname, UL.pos_alias, UL.pos_name
    FROM users U 
    INNER JOIN users_info UI 
    ON (U.user_id = UI.user_id)
    INNER JOIN users_level UL
    ON (U.pos_id = UL.id)
    WHERE U.username = user;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_users_session` (IN `hashVal` TEXT)  NO SQL
BEGIN

	DELETE FROM `users_session`
    WHERE `session_hash` = hashVal;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `set_users_session` (IN `userID` INT(11), IN `hashID` TEXT)  NO SQL
BEGIN

	INSERT INTO `users_session`
    (`user_id`, `session_hash`)
    VALUES
    (userID, hashID);
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `set_users_subscription` (IN `name` VARCHAR(64), IN `emailAdd` VARCHAR(64), IN `ipAdd` TEXT, IN `tzone` VARCHAR(32), IN `cc` VARCHAR(32), IN `reg` VARCHAR(64))  NO SQL
BEGIN

	INSERT INTO `users_subscription`
    (`fname`, `email`, `ip_address`, `timezone`, `country_code`, `region`)
    VALUES 
    (name, emailAdd, ipAdd, tzone, cc, reg);

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ip_blocked`
--

CREATE TABLE `ip_blocked` (
  `id` int(11) NOT NULL,
  `hostname` text NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ip_blocked`
--

INSERT INTO `ip_blocked` (`id`, `hostname`, `created`) VALUES
(1, '127.0.0.1', '2017-04-10 10:29:34'),
(2, '192.168.254.100', '2017-04-10 10:29:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` text NOT NULL,
  `password_salt` text NOT NULL,
  `pos_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `password_salt`, `pos_id`) VALUES
(1, 'admin', 'ZXlIYo77wYpWMuF+dh62A9GzMxLErGoDxKqkg6JDZBs2P21CxCqzDamDOClUJa3P2B+VW5RiVfSgj+yXHSA9tg==', 'Š–C£…Ž$p_-ËàÞæ•qÏ¥È‘¾Û''ÿ<xç', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_info`
--

CREATE TABLE `users_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_info`
--

INSERT INTO `users_info` (`id`, `user_id`, `fname`, `lname`) VALUES
(1, 1, 'Admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_level`
--

CREATE TABLE `users_level` (
  `id` int(11) NOT NULL,
  `pos_alias` varchar(32) NOT NULL,
  `pos_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_level`
--

INSERT INTO `users_level` (`id`, `pos_alias`, `pos_name`) VALUES
(1, 'admin', 'Administrator'),
(2, 'public', 'Public User');

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE `users_session` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_hash` text NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_subscription`
--

CREATE TABLE `users_subscription` (
  `id` int(11) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `ip_address` text NOT NULL,
  `timezone` varchar(32) NOT NULL,
  `country_code` varchar(32) NOT NULL,
  `region` varchar(64) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_subscription`
--

INSERT INTO `users_subscription` (`id`, `fname`, `lname`, `email`, `ip_address`, `timezone`, `country_code`, `region`, `created`) VALUES
(1, 'Rhino Media', '', 'info@rhinomedia.com.au', '::1', '+08:00', 'PH', 'National Capital Region', '2017-04-10 10:56:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ip_blocked`
--
ALTER TABLE `ip_blocked`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_level`
--
ALTER TABLE `users_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_session`
--
ALTER TABLE `users_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_subscription`
--
ALTER TABLE `users_subscription`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ip_blocked`
--
ALTER TABLE `ip_blocked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_info`
--
ALTER TABLE `users_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_level`
--
ALTER TABLE `users_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users_session`
--
ALTER TABLE `users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users_subscription`
--
ALTER TABLE `users_subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
